using Microsoft.AspNetCore.Mvc;
using PayrollAPI.Repositories;

namespace PayrollAPI.Controllers;

[ApiController]
[Route("api/employees")]
public class EmployeesController : ControllerBase
{
    private readonly IEmployeeRepository _repo;

    public EmployeesController(IEmployeeRepository repo)
    {
        _repo = repo;
    }

    /// <summary>
    /// GET /api/employees — returns all active employees
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var employees = await _repo.GetAllAsync();
        return Ok(employees);
    }

    /// <summary>
    /// GET /api/employees/{id} — returns a single employee
    /// </summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var emp = await _repo.GetByIdAsync(id);
        return emp is null ? NotFound(new { message = $"Employee {id} not found." }) : Ok(emp);
    }
}
