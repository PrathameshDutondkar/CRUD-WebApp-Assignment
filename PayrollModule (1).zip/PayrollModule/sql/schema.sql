-- ============================================================
-- Payroll Module — SQL Server Schema Script
-- NOTE: The application uses SQLite (auto-created on first run).
--       This script documents the equivalent SQL Server schema
--       for reference / portability.
-- ============================================================

-- Departments
CREATE TABLE Departments (
    Id    INT IDENTITY(1,1) PRIMARY KEY,
    Name  NVARCHAR(100) NOT NULL UNIQUE
);

-- Employees
CREATE TABLE Employees (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    Name         NVARCHAR(150)  NOT NULL,
    Email        NVARCHAR(200)  NOT NULL UNIQUE,
    DepartmentId INT            NOT NULL,
    BasicSalary  DECIMAL(12,2)  NOT NULL CHECK (BasicSalary > 0),
    JoiningDate  DATE           NOT NULL,
    IsActive     BIT            NOT NULL DEFAULT 1,
    CONSTRAINT FK_Employees_Departments FOREIGN KEY (DepartmentId) REFERENCES Departments(Id)
);

CREATE INDEX IX_Employees_DepartmentId ON Employees(DepartmentId);

-- Attendance
CREATE TABLE Attendance (
    Id               INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeId       INT NOT NULL,
    Month            TINYINT NOT NULL CHECK (Month BETWEEN 1 AND 12),
    Year             SMALLINT NOT NULL CHECK (Year >= 2000),
    DaysPresent      TINYINT NOT NULL CHECK (DaysPresent >= 0),
    TotalWorkingDays TINYINT NOT NULL CHECK (TotalWorkingDays > 0),
    CONSTRAINT FK_Attendance_Employees FOREIGN KEY (EmployeeId) REFERENCES Employees(Id),
    CONSTRAINT UQ_Attendance_Emp_Month_Year UNIQUE (EmployeeId, Month, Year),
    CONSTRAINT CHK_DaysPresent_LTE_Working CHECK (DaysPresent <= TotalWorkingDays)
);

CREATE INDEX IX_Attendance_EmpMonthYear ON Attendance(EmployeeId, Month, Year);

-- Payroll Runs (immutable once created)
CREATE TABLE PayrollRuns (
    Id      INT IDENTITY(1,1) PRIMARY KEY,
    Month   TINYINT  NOT NULL CHECK (Month BETWEEN 1 AND 12),
    Year    SMALLINT NOT NULL CHECK (Year >= 2000),
    RunDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Status  NVARCHAR(20) NOT NULL DEFAULT 'Finalised',
    CONSTRAINT UQ_PayrollRuns_MonthYear UNIQUE (Month, Year)
);

-- Payroll Details (per-employee snapshot — never changes after insert)
CREATE TABLE PayrollDetails (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    PayrollRunId    INT           NOT NULL,
    EmployeeId      INT           NOT NULL,
    EmployeeName    NVARCHAR(150) NOT NULL,   -- snapshot at time of run
    Department      NVARCHAR(100) NOT NULL,   -- snapshot at time of run
    BasicSalary     DECIMAL(12,2) NOT NULL,
    TotalWorkingDays TINYINT      NOT NULL,
    DaysPresent     TINYINT       NOT NULL,
    GrossPay        DECIMAL(12,2) NOT NULL,
    PFDeduction     DECIMAL(12,2) NOT NULL,
    ProfessionalTax DECIMAL(12,2) NOT NULL,
    NetPay          DECIMAL(12,2) NOT NULL,
    CONSTRAINT FK_PayrollDetails_Runs      FOREIGN KEY (PayrollRunId) REFERENCES PayrollRuns(Id),
    CONSTRAINT FK_PayrollDetails_Employees FOREIGN KEY (EmployeeId)   REFERENCES Employees(Id)
);

CREATE INDEX IX_PayrollDetails_RunId ON PayrollDetails(PayrollRunId);
