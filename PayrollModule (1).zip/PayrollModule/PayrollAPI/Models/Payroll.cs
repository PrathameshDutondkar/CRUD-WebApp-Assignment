namespace PayrollAPI.Models;

public class PayrollRun
{
    public int Id { get; set; }
    public int Month { get; set; }
    public int Year { get; set; }
    public DateTime RunDate { get; set; }
    public string Status { get; set; } = "Finalised"; // Once saved, always Finalised
    public List<PayrollDetail> Details { get; set; } = new();
}

public class PayrollDetail
{
    public int Id { get; set; }
    public int PayrollRunId { get; set; }
    public int EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public decimal BasicSalary { get; set; }
    public int TotalWorkingDays { get; set; }
    public int DaysPresent { get; set; }
    public decimal GrossPay { get; set; }
    public decimal PFDeduction { get; set; }
    public decimal ProfessionalTax { get; set; }
    public decimal NetPay { get; set; }
}

public class PayrollRunRequest
{
    public int Month { get; set; }
    public int Year { get; set; }
}
