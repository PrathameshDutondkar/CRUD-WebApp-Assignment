using Microsoft.Data.Sqlite;

namespace PayrollAPI.Data;

public class DatabaseContext
{
    private readonly string _connectionString;

    public DatabaseContext(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Data Source=payroll.db";
    }

    public SqliteConnection CreateConnection() => new SqliteConnection(_connectionString);
}

public static class DatabaseInitializer
{
    public static void Initialize(IServiceProvider services)
    {
        var db = services.GetRequiredService<DatabaseContext>();
        using var conn = db.CreateConnection();
        conn.Open();

        // Create tables
        var createTables = @"
            CREATE TABLE IF NOT EXISTS Departments (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS Employees (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name TEXT NOT NULL,
                Email TEXT NOT NULL UNIQUE,
                DepartmentId INTEGER NOT NULL,
                BasicSalary DECIMAL(12,2) NOT NULL,
                JoiningDate TEXT NOT NULL,
                IsActive INTEGER NOT NULL DEFAULT 1,
                FOREIGN KEY (DepartmentId) REFERENCES Departments(Id)
            );

            CREATE TABLE IF NOT EXISTS Attendance (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                EmployeeId INTEGER NOT NULL,
                Month INTEGER NOT NULL,
                Year INTEGER NOT NULL,
                DaysPresent INTEGER NOT NULL,
                TotalWorkingDays INTEGER NOT NULL,
                FOREIGN KEY (EmployeeId) REFERENCES Employees(Id),
                UNIQUE (EmployeeId, Month, Year)
            );

            CREATE TABLE IF NOT EXISTS PayrollRuns (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Month INTEGER NOT NULL,
                Year INTEGER NOT NULL,
                RunDate TEXT NOT NULL,
                Status TEXT NOT NULL DEFAULT 'Finalised',
                UNIQUE (Month, Year)
            );

            CREATE TABLE IF NOT EXISTS PayrollDetails (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                PayrollRunId INTEGER NOT NULL,
                EmployeeId INTEGER NOT NULL,
                EmployeeName TEXT NOT NULL,
                Department TEXT NOT NULL,
                BasicSalary DECIMAL(12,2) NOT NULL,
                TotalWorkingDays INTEGER NOT NULL,
                DaysPresent INTEGER NOT NULL,
                GrossPay DECIMAL(12,2) NOT NULL,
                PFDeduction DECIMAL(12,2) NOT NULL,
                ProfessionalTax DECIMAL(12,2) NOT NULL,
                NetPay DECIMAL(12,2) NOT NULL,
                FOREIGN KEY (PayrollRunId) REFERENCES PayrollRuns(Id),
                FOREIGN KEY (EmployeeId) REFERENCES Employees(Id)
            );

            CREATE INDEX IF NOT EXISTS idx_attendance_emp_month ON Attendance(EmployeeId, Month, Year);
            CREATE INDEX IF NOT EXISTS idx_payroll_details_run ON PayrollDetails(PayrollRunId);
        ";

        using var cmd = conn.CreateCommand();
        cmd.CommandText = createTables;
        cmd.ExecuteNonQuery();

        // Seed data
        SeedData(conn);
    }

    private static void SeedData(SqliteConnection conn)
    {
        using var cmd = conn.CreateCommand();

        // Check if already seeded
        cmd.CommandText = "SELECT COUNT(*) FROM Employees";
        var count = (long)(cmd.ExecuteScalar() ?? 0L);
        if (count > 0) return;

        // Departments
        cmd.CommandText = @"
            INSERT INTO Departments (Name) VALUES ('Engineering'), ('Human Resources');
        ";
        cmd.ExecuteNonQuery();

        // Employees - 5 employees across 2 departments
        cmd.CommandText = @"
            INSERT INTO Employees (Name, Email, DepartmentId, BasicSalary, JoiningDate, IsActive) VALUES
            ('Ravi Sharma',    'ravi.sharma@company.com',    1, 30000.00, '2022-01-10', 1),
            ('Priya Mehta',    'priya.mehta@company.com',    1, 45000.00, '2021-06-15', 1),
            ('Amit Kulkarni',  'amit.kulkarni@company.com',  1, 52000.00, '2020-03-20', 1),
            ('Sunita Patil',   'sunita.patil@company.com',   2, 38000.00, '2022-08-01', 1),
            ('Deepak Joshi',   'deepak.joshi@company.com',   2, 41000.00, '2021-11-05', 1);
        ";
        cmd.ExecuteNonQuery();

        // Attendance for current month
        var now = DateTime.Now;
        var month = now.Month;
        var year = now.Year;

        cmd.CommandText = $@"
            INSERT INTO Attendance (EmployeeId, Month, Year, DaysPresent, TotalWorkingDays) VALUES
            (1, {month}, {year}, 24, 26),
            (2, {month}, {year}, 26, 26),
            (3, {month}, {year}, 22, 26),
            (4, {month}, {year}, 25, 26),
            (5, {month}, {year},  0, 26);
        ";
        cmd.ExecuteNonQuery();
    }
}
