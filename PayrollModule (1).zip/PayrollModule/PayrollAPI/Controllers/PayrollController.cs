using Microsoft.AspNetCore.Mvc;
using PayrollAPI.Models;
using PayrollAPI.Services;

namespace PayrollAPI.Controllers;

[ApiController]
[Route("api/payroll")]
public class PayrollController : ControllerBase
{
    private readonly IPayrollService _service;
    private readonly ILogger<PayrollController> _logger;

    public PayrollController(IPayrollService service, ILogger<PayrollController> logger)
    {
        _service = service;
        _logger = logger;
    }

    /// <summary>
    /// POST /api/payroll/run
    /// Triggers a payroll run for the given month and year.
    /// Returns 409 Conflict if a run already exists for that period (bonus requirement).
    /// </summary>
    [HttpPost("run")]
    public async Task<IActionResult> RunPayroll([FromBody] PayrollRunRequest request)
    {
        if (request.Month < 1 || request.Month > 12)
            return BadRequest(new { message = "Month must be between 1 and 12." });

        if (request.Year < 2000 || request.Year > 2100)
            return BadRequest(new { message = "Year is out of valid range." });

        try
        {
            var run = await _service.RunPayrollAsync(request.Month, request.Year);
            return CreatedAtAction(
                nameof(GetPayroll),
                new { month = run.Month, year = run.Year },
                run
            );
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("already been finalised"))
        {
            // Bonus: 409 Conflict when payroll already exists
            _logger.LogWarning("Payroll run conflict: {Message}", ex.Message);
            return Conflict(new { message = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error running payroll for {Month}/{Year}", request.Month, request.Year);
            return StatusCode(500, new { message = "An unexpected error occurred." });
        }
    }

    /// <summary>
    /// GET /api/payroll/{month}/{year}
    /// Returns the saved payroll run for the given month and year.
    /// </summary>
    [HttpGet("{month:int}/{year:int}")]
    public async Task<IActionResult> GetPayroll(int month, int year)
    {
        var run = await _service.GetPayrollAsync(month, year);
        return run is null
            ? NotFound(new { message = $"No payroll run found for {month}/{year}." })
            : Ok(run);
    }

    /// <summary>
    /// GET /api/payroll/{runId}/slip/{employeeId}
    /// Returns an individual payslip for one employee in a payroll run.
    /// </summary>
    [HttpGet("{runId:int}/slip/{employeeId:int}")]
    public async Task<IActionResult> GetPayslip(int runId, int employeeId)
    {
        var slip = await _service.GetPayslipAsync(runId, employeeId);
        return slip is null
            ? NotFound(new { message = $"No payslip found for employee {employeeId} in run {runId}." })
            : Ok(slip);
    }
}
