using PayrollAPI.Data;
using PayrollAPI.Models;
using Microsoft.Data.Sqlite;

namespace PayrollAPI.Repositories;

public interface IEmployeeRepository
{
    Task<IEnumerable<Employee>> GetAllAsync();
    Task<Employee?> GetByIdAsync(int id);
}

public class EmployeeRepository : IEmployeeRepository
{
    private readonly DatabaseContext _db;

    public EmployeeRepository(DatabaseContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<Employee>> GetAllAsync()
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        var employees = new List<Employee>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT e.Id, e.Name, e.Email, d.Name AS Department, e.BasicSalary, e.JoiningDate, e.IsActive
            FROM Employees e
            INNER JOIN Departments d ON d.Id = e.DepartmentId
            WHERE e.IsActive = 1
            ORDER BY e.Name
        ";

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            employees.Add(new Employee
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Email = reader.GetString(2),
                Department = reader.GetString(3),
                BasicSalary = reader.GetDecimal(4),
                JoiningDate = DateTime.Parse(reader.GetString(5)),
                IsActive = reader.GetInt32(6) == 1
            });
        }
        return employees;
    }

    public async Task<Employee?> GetByIdAsync(int id)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT e.Id, e.Name, e.Email, d.Name AS Department, e.BasicSalary, e.JoiningDate, e.IsActive
            FROM Employees e
            INNER JOIN Departments d ON d.Id = e.DepartmentId
            WHERE e.Id = $id
        ";
        cmd.Parameters.AddWithValue("$id", id);

        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new Employee
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Email = reader.GetString(2),
                Department = reader.GetString(3),
                BasicSalary = reader.GetDecimal(4),
                JoiningDate = DateTime.Parse(reader.GetString(5)),
                IsActive = reader.GetInt32(6) == 1
            };
        }
        return null;
    }
}
