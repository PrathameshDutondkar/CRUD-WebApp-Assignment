using PayrollAPI.Data;
using PayrollAPI.Models;
using Microsoft.Data.Sqlite;

namespace PayrollAPI.Repositories;

public interface IPayrollRepository
{
    Task<bool> RunExistsAsync(int month, int year);
    Task<PayrollRun?> GetByMonthYearAsync(int month, int year);
    Task<PayrollRun?> GetByIdAsync(int runId);
    Task<PayrollDetail?> GetSlipAsync(int runId, int employeeId);
    Task<int> SavePayrollRunAsync(PayrollRun run, IEnumerable<PayrollDetail> details);
}

public class PayrollRepository : IPayrollRepository
{
    private readonly DatabaseContext _db;

    public PayrollRepository(DatabaseContext db)
    {
        _db = db;
    }

    public async Task<bool> RunExistsAsync(int month, int year)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM PayrollRuns WHERE Month = $m AND Year = $y";
        cmd.Parameters.AddWithValue("$m", month);
        cmd.Parameters.AddWithValue("$y", year);
        return (long)(await cmd.ExecuteScalarAsync() ?? 0L) > 0;
    }

    public async Task<PayrollRun?> GetByMonthYearAsync(int month, int year)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, Month, Year, RunDate, Status FROM PayrollRuns WHERE Month = $m AND Year = $y";
        cmd.Parameters.AddWithValue("$m", month);
        cmd.Parameters.AddWithValue("$y", year);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;

        var run = new PayrollRun
        {
            Id = reader.GetInt32(0),
            Month = reader.GetInt32(1),
            Year = reader.GetInt32(2),
            RunDate = DateTime.Parse(reader.GetString(3)),
            Status = reader.GetString(4)
        };

        run.Details = (await GetDetailsAsync(conn, run.Id)).ToList();
        return run;
    }

    public async Task<PayrollRun?> GetByIdAsync(int runId)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, Month, Year, RunDate, Status FROM PayrollRuns WHERE Id = $id";
        cmd.Parameters.AddWithValue("$id", runId);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;

        var run = new PayrollRun
        {
            Id = reader.GetInt32(0),
            Month = reader.GetInt32(1),
            Year = reader.GetInt32(2),
            RunDate = DateTime.Parse(reader.GetString(3)),
            Status = reader.GetString(4)
        };
        run.Details = (await GetDetailsAsync(conn, run.Id)).ToList();
        return run;
    }

    public async Task<PayrollDetail?> GetSlipAsync(int runId, int employeeId)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT Id, PayrollRunId, EmployeeId, EmployeeName, Department, BasicSalary,
                   TotalWorkingDays, DaysPresent, GrossPay, PFDeduction, ProfessionalTax, NetPay
            FROM PayrollDetails
            WHERE PayrollRunId = $runId AND EmployeeId = $empId
        ";
        cmd.Parameters.AddWithValue("$runId", runId);
        cmd.Parameters.AddWithValue("$empId", employeeId);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;
        return MapDetail(reader);
    }

    public async Task<int> SavePayrollRunAsync(PayrollRun run, IEnumerable<PayrollDetail> details)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();
        using var tx = conn.BeginTransaction();

        try
        {
            using var insertRun = conn.CreateCommand();
            insertRun.Transaction = tx;
            insertRun.CommandText = @"
                INSERT INTO PayrollRuns (Month, Year, RunDate, Status)
                VALUES ($m, $y, $rd, $st);
                SELECT last_insert_rowid();
            ";
            insertRun.Parameters.AddWithValue("$m", run.Month);
            insertRun.Parameters.AddWithValue("$y", run.Year);
            insertRun.Parameters.AddWithValue("$rd", run.RunDate.ToString("o"));
            insertRun.Parameters.AddWithValue("$st", run.Status);

            var runId = (long)(await insertRun.ExecuteScalarAsync() ?? 0L);

            foreach (var d in details)
            {
                using var insertDetail = conn.CreateCommand();
                insertDetail.Transaction = tx;
                insertDetail.CommandText = @"
                    INSERT INTO PayrollDetails
                        (PayrollRunId, EmployeeId, EmployeeName, Department, BasicSalary,
                         TotalWorkingDays, DaysPresent, GrossPay, PFDeduction, ProfessionalTax, NetPay)
                    VALUES ($rid, $eid, $en, $dept, $bs, $twd, $dp, $gp, $pf, $pt, $np)
                ";
                insertDetail.Parameters.AddWithValue("$rid", runId);
                insertDetail.Parameters.AddWithValue("$eid", d.EmployeeId);
                insertDetail.Parameters.AddWithValue("$en", d.EmployeeName);
                insertDetail.Parameters.AddWithValue("$dept", d.Department);
                insertDetail.Parameters.AddWithValue("$bs", d.BasicSalary);
                insertDetail.Parameters.AddWithValue("$twd", d.TotalWorkingDays);
                insertDetail.Parameters.AddWithValue("$dp", d.DaysPresent);
                insertDetail.Parameters.AddWithValue("$gp", d.GrossPay);
                insertDetail.Parameters.AddWithValue("$pf", d.PFDeduction);
                insertDetail.Parameters.AddWithValue("$pt", d.ProfessionalTax);
                insertDetail.Parameters.AddWithValue("$np", d.NetPay);
                await insertDetail.ExecuteNonQueryAsync();
            }

            await tx.CommitAsync();
            return (int)runId;
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }

    private async Task<IEnumerable<PayrollDetail>> GetDetailsAsync(SqliteConnection conn, int runId)
    {
        var details = new List<PayrollDetail>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT Id, PayrollRunId, EmployeeId, EmployeeName, Department, BasicSalary,
                   TotalWorkingDays, DaysPresent, GrossPay, PFDeduction, ProfessionalTax, NetPay
            FROM PayrollDetails WHERE PayrollRunId = $rid ORDER BY EmployeeName
        ";
        cmd.Parameters.AddWithValue("$rid", runId);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            details.Add(MapDetail(reader));

        return details;
    }

    private static PayrollDetail MapDetail(SqliteDataReader reader) => new()
    {
        Id = reader.GetInt32(0),
        PayrollRunId = reader.GetInt32(1),
        EmployeeId = reader.GetInt32(2),
        EmployeeName = reader.GetString(3),
        Department = reader.GetString(4),
        BasicSalary = reader.GetDecimal(5),
        TotalWorkingDays = reader.GetInt32(6),
        DaysPresent = reader.GetInt32(7),
        GrossPay = reader.GetDecimal(8),
        PFDeduction = reader.GetDecimal(9),
        ProfessionalTax = reader.GetDecimal(10),
        NetPay = reader.GetDecimal(11)
    };
}
