using PayrollAPI.Data;
using PayrollAPI.Models;
using Microsoft.Data.Sqlite;

namespace PayrollAPI.Services;

public interface IPayrollService
{
    Task<PayrollRun> RunPayrollAsync(int month, int year);
    Task<PayrollRun?> GetPayrollAsync(int month, int year);
    Task<PayrollDetail?> GetPayslipAsync(int runId, int employeeId);
}

public class PayrollService : IPayrollService
{
    private readonly DatabaseContext _db;
    private readonly Repositories.IPayrollRepository _payrollRepo;

    // Business rule constants
    private const decimal PF_RATE = 0.12m;
    private const decimal PROFESSIONAL_TAX = 200m;

    public PayrollService(DatabaseContext db, Repositories.IPayrollRepository payrollRepo)
    {
        _db = db;
        _payrollRepo = payrollRepo;
    }

    public async Task<PayrollRun> RunPayrollAsync(int month, int year)
    {
        // Immutability rule: cannot re-run payroll for existing month/year
        if (await _payrollRepo.RunExistsAsync(month, year))
            throw new InvalidOperationException($"Payroll for {month}/{year} has already been finalised and cannot be re-run.");

        // Fetch employees with their attendance for the given month
        var employeeAttendances = await GetEmployeeAttendancesAsync(month, year);

        if (!employeeAttendances.Any())
            throw new InvalidOperationException($"No employees with attendance records found for {month}/{year}.");

        // Calculate payroll for each employee
        var details = employeeAttendances.Select(ea => CalculatePayroll(ea.employee, ea.attendance)).ToList();

        var run = new PayrollRun
        {
            Month = month,
            Year = year,
            RunDate = DateTime.UtcNow,
            Status = "Finalised"
        };

        var runId = await _payrollRepo.SavePayrollRunAsync(run, details);
        run.Id = runId;
        run.Details = details;

        return run;
    }

    /// <summary>
    /// Core payroll calculation logic.
    /// Gross Pay = (Basic Salary / Total Working Days) * Days Present
    /// PF = 12% of Basic Salary
    /// Professional Tax = flat ₹200
    /// Net Pay = Gross Pay - PF - Professional Tax
    /// Edge case: if DaysPresent = 0, GrossPay = 0, still deduct PF and PT → NetPay can be negative
    /// We floor NetPay at 0 since the company won't claim money back.
    /// </summary>
    public static PayrollDetail CalculatePayroll(Employee emp, Attendance att)
    {
        decimal grossPay = att.TotalWorkingDays > 0
            ? Math.Round((emp.BasicSalary / att.TotalWorkingDays) * att.DaysPresent, 2)
            : 0m;

        decimal pf = Math.Round(emp.BasicSalary * PF_RATE, 2);
        decimal pt = PROFESSIONAL_TAX;

        // Net pay is floored at 0 — company does not recover money from absent employees
        decimal netPay = Math.Max(0, grossPay - pf - pt);

        return new PayrollDetail
        {
            EmployeeId = emp.Id,
            EmployeeName = emp.Name,
            Department = emp.Department,
            BasicSalary = emp.BasicSalary,
            TotalWorkingDays = att.TotalWorkingDays,
            DaysPresent = att.DaysPresent,
            GrossPay = grossPay,
            PFDeduction = pf,
            ProfessionalTax = pt,
            NetPay = netPay
        };
    }

    public async Task<PayrollRun?> GetPayrollAsync(int month, int year)
        => await _payrollRepo.GetByMonthYearAsync(month, year);

    public async Task<PayrollDetail?> GetPayslipAsync(int runId, int employeeId)
        => await _payrollRepo.GetSlipAsync(runId, employeeId);

    private async Task<List<(Employee employee, Attendance attendance)>> GetEmployeeAttendancesAsync(int month, int year)
    {
        using var conn = _db.CreateConnection();
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT e.Id, e.Name, e.Email, d.Name AS Department, e.BasicSalary, e.JoiningDate,
                   a.DaysPresent, a.TotalWorkingDays
            FROM Employees e
            INNER JOIN Departments d ON d.Id = e.DepartmentId
            INNER JOIN Attendance a ON a.EmployeeId = e.Id AND a.Month = $m AND a.Year = $y
            WHERE e.IsActive = 1
        ";
        cmd.Parameters.AddWithValue("$m", month);
        cmd.Parameters.AddWithValue("$y", year);

        var result = new List<(Employee, Attendance)>();
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var emp = new Employee
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Email = reader.GetString(2),
                Department = reader.GetString(3),
                BasicSalary = reader.GetDecimal(4),
                JoiningDate = DateTime.Parse(reader.GetString(5))
            };
            var att = new Attendance
            {
                EmployeeId = emp.Id,
                Month = month,
                Year = year,
                DaysPresent = reader.GetInt32(6),
                TotalWorkingDays = reader.GetInt32(7)
            };
            result.Add((emp, att));
        }
        return result;
    }
}
