# Payroll Module — Full Stack Developer Assessment

## Overview

A complete **Employee Payroll Run Module** built with:

- **Backend:** ASP.NET Core 8 Web API (C#) with ADO.NET
- **Database:** SQLite (embedded, zero setup — `payroll.db` auto-created on first run)
- **Frontend:** React 18 + Vite
- **Tests:** xUnit with 9 unit tests covering all payroll calculation edge cases

---

## How to Run Locally

### Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| .NET SDK | 8.0+ | https://dotnet.microsoft.com/download |
| Node.js | 18+ | https://nodejs.org |
| npm | 9+ | bundled with Node |

### Step 1 — Start the API

```bash
cd PayrollAPI
dotnet restore
dotnet run
```

The API starts at **http://localhost:5000**  
Swagger UI is available at **http://localhost:5000/swagger**

> The SQLite database (`payroll.db`) is created automatically in the `PayrollAPI` folder on first run,
> along with tables and seed data (5 employees across 2 departments, attendance for the current month).

### Step 2 — Start the Frontend

Open a new terminal:

```bash
cd payroll-ui
npm install
npm run dev
```

The React app starts at **http://localhost:5173**

### Step 3 — Run Tests

```bash
cd PayrollAPI.Tests
dotnet restore
dotnet test
```

---

## Database Setup

No manual database setup is required. On first `dotnet run`:

1. SQLite file `payroll.db` is created in the `PayrollAPI` directory.
2. All tables are created with foreign keys and indexes.
3. Seed data is inserted: 5 employees (3 in Engineering, 2 in HR) + attendance for the current month.

**Connection string** (in `appsettings.json`):
```json
"ConnectionStrings": {
  "DefaultConnection": "Data Source=payroll.db"
}
```

To reset the database, simply delete `PayrollAPI/payroll.db` and restart.

---

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET`  | `/api/employees` | List all active employees |
| `POST` | `/api/payroll/run` | Trigger payroll run `{ month, year }` |
| `GET`  | `/api/payroll/{month}/{year}` | Get saved payroll run |
| `GET`  | `/api/payroll/{runId}/slip/{employeeId}` | Get individual payslip |

All endpoints documented in Swagger at `/swagger`.

---

## Payroll Calculation Logic

```
Gross Pay    = (BasicSalary ÷ TotalWorkingDays) × DaysPresent
PF Deduction = 12% of BasicSalary  (always on full basic, not gross)
Prof. Tax    = ₹200 flat
Net Pay      = GrossPay − PF − ProfessionalTax  (floored at ₹0)
```

**Edge cases handled:**
- `DaysPresent = 0` → GrossPay = ₹0, but PF is still deducted on BasicSalary; NetPay floored at ₹0
- `TotalWorkingDays = 0` → GrossPay = ₹0 (prevents division by zero)
- Payroll immutability: once finalised, re-running the same month returns **HTTP 409 Conflict**

---

## Assumptions Made

1. **SQLite over SQL Server** — The brief specifies SQL Server but also asks for zero setup. SQLite is embedded and requires no installation. The schema, logic, and stored procedure are provided in the `/sql` folder as SQL Server-compatible scripts for reference.

2. **PF on full BasicSalary** — The brief says "12% of Basic Salary". I calculate PF on the full basic salary, not the prorated gross pay. This is standard Indian payroll practice.

3. **Attendance must exist to run payroll** — If an employee has no attendance record for the selected month, they are excluded from the payroll run (not treated as 0 days). The API returns 400 if no employees have attendance for the month.

4. **NetPay floor at ₹0** — For an employee with 0 days present, PF + Professional Tax exceeds GrossPay. The company does not recover money; NetPay is capped at ₹0.

5. **Snapshot of employee data** — PayrollDetails stores the employee name and department at the time of the run. This ensures historical payslips remain accurate even if employee data changes later.

6. **No authentication** — JWT auth is not implemented as the brief focuses on payroll logic. In production, all endpoints would require authentication.

7. **CORS** — The API allows `localhost:3000` and `localhost:5173` (Vite dev server). In production, this would be restricted.

---

## Bonus Deliverables Completed

- ✅ **HTTP 409 Conflict** when payroll already exists for the month/year
- ✅ **Unit tests** (xUnit) — 9 tests covering all calculation scenarios
- ✅ **Printable payslip view** per employee (opens in new tab, browser print dialog)

---

## What I Would Add With More Time

1. **SQL Server support** — Add a feature flag to switch between SQLite (dev) and SQL Server (prod) via connection string.
2. **JWT Authentication** — Protect endpoints; HR role vs read-only role.
3. **Pagination** on `GET /api/payroll/{month}/{year}` for large employee sets.
4. **Attendance management UI** — Currently attendance is seeded; HR should be able to enter/edit attendance before running payroll.
5. **Payroll history list** — A `GET /api/payroll` endpoint listing all past runs.
6. **Integration tests** — Test the full HTTP pipeline with an in-memory SQLite database.
7. **Docker support** — Containerize both API and frontend with `docker-compose`.
8. **Error boundary** in React for graceful frontend error handling.

---

## Project Structure

```
PayrollModule/
├── PayrollAPI/                   # ASP.NET Core 8 Web API
│   ├── Controllers/
│   │   ├── EmployeesController.cs
│   │   └── PayrollController.cs
│   ├── Services/
│   │   └── PayrollService.cs     # Business logic + calculation
│   ├── Repositories/
│   │   ├── EmployeeRepository.cs
│   │   └── PayrollRepository.cs
│   ├── Models/
│   │   ├── Employee.cs
│   │   ├── Attendance.cs
│   │   └── Payroll.cs
│   ├── Data/
│   │   └── DatabaseContext.cs    # SQLite init + seeding
│   └── Program.cs
├── PayrollAPI.Tests/             # xUnit tests
│   └── PayrollCalculationTests.cs
├── payroll-ui/                   # React + Vite frontend
│   └── src/
│       ├── App.jsx               # Main UI (tabs: Run / View / Employees)
│       ├── api.js                # API service layer
│       └── components/
│           └── PayslipModal.jsx  # Printable payslip
└── sql/
    ├── schema.sql                # SQL Server schema reference
    ├── seed.sql                  # SQL Server seed data reference
    └── usp_RunPayroll.sql        # Stored procedure reference
```
