const BASE_URL = '/api';

export const api = {
  getEmployees: async () => {
    const res = await fetch(`${BASE_URL}/employees`);
    if (!res.ok) throw new Error('Failed to fetch employees');
    return res.json();
  },

  runPayroll: async (month, year) => {
    const res = await fetch(`${BASE_URL}/payroll/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ month, year }),
    });
    const data = await res.json();
    if (res.status === 409) throw { status: 409, message: data.message };
    if (!res.ok) throw new Error(data.message || 'Failed to run payroll');
    return data;
  },

  getPayroll: async (month, year) => {
    const res = await fetch(`${BASE_URL}/payroll/${month}/${year}`);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error('Failed to fetch payroll');
    return res.json();
  },

  getPayslip: async (runId, employeeId) => {
    const res = await fetch(`${BASE_URL}/payroll/${runId}/slip/${employeeId}`);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error('Failed to fetch payslip');
    return res.json();
  },
};

export const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
];

export const formatCurrency = (amount) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
