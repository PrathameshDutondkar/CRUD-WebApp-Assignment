using PayrollAPI.Models;
using PayrollAPI.Services;
using Xunit;

namespace PayrollAPI.Tests;

/// <summary>
/// Unit tests for the core payroll calculation logic in PayrollService.
/// Tests are focused on CalculatePayroll which is the pure business logic method.
/// </summary>
public class PayrollCalculationTests
{
    private static Employee MakeEmployee(decimal basicSalary) => new()
    {
        Id = 1,
        Name = "Test Employee",
        Email = "test@company.com",
        Department = "Engineering",
        BasicSalary = basicSalary,
        JoiningDate = DateTime.Now.AddYears(-1)
    };

    private static Attendance MakeAttendance(int daysPresent, int totalWorkingDays) => new()
    {
        EmployeeId = 1,
        Month = 5,
        Year = 2025,
        DaysPresent = daysPresent,
        TotalWorkingDays = totalWorkingDays
    };

    [Fact]
    public void GivenFullAttendance_GrossPayEqualBasicSalary()
    {
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(26, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(30000m, result.GrossPay);
    }

    [Fact]
    public void GivenPartialAttendance_GrossPayIsProrated()
    {
        // Example from the brief: Ravi Sharma
        // Basic=30000, WorkingDays=26, DaysPresent=24
        // GrossPay = (30000/26)*24 = 27692.31 → rounded to 27692.31
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(24, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(27692.31m, result.GrossPay);
    }

    [Fact]
    public void PFDeductionIs12PercentOfBasicSalary()
    {
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(26, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(3600m, result.PFDeduction); // 12% of 30000
    }

    [Fact]
    public void ProfessionalTaxIsFlatRs200()
    {
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(26, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(200m, result.ProfessionalTax);
    }

    [Fact]
    public void NetPayIsGrossMinusPFMinusPT()
    {
        // Ravi's example from the brief: GrossPay=27692, PF=3600, PT=200 → Net=23892
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(24, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        var expectedNet = result.GrossPay - result.PFDeduction - result.ProfessionalTax;
        Assert.Equal(Math.Round(expectedNet, 2), result.NetPay);
    }

    [Fact]
    public void EdgeCase_ZeroDaysPresent_GrossPayIsZero()
    {
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(0, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(0m, result.GrossPay);
    }

    [Fact]
    public void EdgeCase_ZeroDaysPresent_NetPayIsZeroNotNegative()
    {
        // Even though PF+PT > GrossPay(0), NetPay is floored at 0
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(0, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(0m, result.NetPay);
        Assert.True(result.NetPay >= 0, "NetPay should never be negative");
    }

    [Fact]
    public void EdgeCase_ZeroTotalWorkingDays_GrossPayIsZero()
    {
        // Guard against division by zero
        var emp = MakeEmployee(30000);
        var att = MakeAttendance(0, 0);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(0m, result.GrossPay);
    }

    [Fact]
    public void PFIsAlwaysBasedOnFullBasicSalaryNotGross()
    {
        // PF must be 12% of BasicSalary regardless of days present
        var emp = MakeEmployee(45000);
        var att = MakeAttendance(10, 26); // only 10 days present

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(Math.Round(45000m * 0.12m, 2), result.PFDeduction);
    }

    [Fact]
    public void FullSalaryRun_VerifyAllFields()
    {
        var emp = MakeEmployee(45000);
        var att = MakeAttendance(26, 26);

        var result = PayrollService.CalculatePayroll(emp, att);

        Assert.Equal(1, result.EmployeeId);
        Assert.Equal("Test Employee", result.EmployeeName);
        Assert.Equal(45000m, result.BasicSalary);
        Assert.Equal(26, result.TotalWorkingDays);
        Assert.Equal(26, result.DaysPresent);
        Assert.Equal(45000m, result.GrossPay);
        Assert.Equal(5400m, result.PFDeduction);
        Assert.Equal(200m, result.ProfessionalTax);
        Assert.Equal(39400m, result.NetPay);
    }
}
