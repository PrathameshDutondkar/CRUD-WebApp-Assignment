-- ============================================================
-- Stored Procedure: usp_RunPayroll
-- Calculates and saves payroll for a given month and year.
-- Raises an error if a run already exists (immutability rule).
-- ============================================================
CREATE OR ALTER PROCEDURE usp_RunPayroll
    @Month INT,
    @Year  INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Validate inputs
    IF @Month < 1 OR @Month > 12
        THROW 50001, 'Month must be between 1 and 12.', 1;

    -- Immutability check: cannot re-run for existing month/year
    IF EXISTS (SELECT 1 FROM PayrollRuns WHERE Month = @Month AND Year = @Year)
        THROW 50002, 'Payroll for this month/year has already been finalised.', 1;

    BEGIN TRANSACTION;

    -- Insert the payroll run header
    INSERT INTO PayrollRuns (Month, Year, RunDate, Status)
    VALUES (@Month, @Year, GETUTCDATE(), 'Finalised');

    DECLARE @RunId INT = SCOPE_IDENTITY();

    -- Calculate and insert per-employee payroll details
    INSERT INTO PayrollDetails
        (PayrollRunId, EmployeeId, EmployeeName, Department, BasicSalary,
         TotalWorkingDays, DaysPresent, GrossPay, PFDeduction, ProfessionalTax, NetPay)
    SELECT
        @RunId,
        e.Id,
        e.Name,
        d.Name,
        e.BasicSalary,
        a.TotalWorkingDays,
        a.DaysPresent,
        -- Gross Pay = (BasicSalary / TotalWorkingDays) * DaysPresent
        ROUND((e.BasicSalary / CAST(a.TotalWorkingDays AS DECIMAL(10,2))) * a.DaysPresent, 2),
        -- PF = 12% of BasicSalary (always on full basic, not gross)
        ROUND(e.BasicSalary * 0.12, 2),
        -- Professional Tax = flat Rs 200
        200.00,
        -- Net Pay = Gross - PF - PT (floored at 0)
        GREATEST(0,
            ROUND((e.BasicSalary / CAST(a.TotalWorkingDays AS DECIMAL(10,2))) * a.DaysPresent, 2)
            - ROUND(e.BasicSalary * 0.12, 2)
            - 200.00
        )
    FROM Employees e
    INNER JOIN Departments d  ON d.Id = e.DepartmentId
    INNER JOIN Attendance  a  ON a.EmployeeId = e.Id
                              AND a.Month = @Month
                              AND a.Year  = @Year
    WHERE e.IsActive = 1;

    COMMIT TRANSACTION;

    -- Return the run summary
    SELECT pr.Id AS RunId, pr.Month, pr.Year, pr.RunDate, pr.Status,
           pd.*
    FROM PayrollRuns pr
    INNER JOIN PayrollDetails pd ON pd.PayrollRunId = pr.Id
    WHERE pr.Id = @RunId;
END;
