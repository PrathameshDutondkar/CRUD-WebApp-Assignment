-- ============================================================
-- Seed Data Script
-- NOTE: The application auto-seeds on first launch via
--       DatabaseInitializer.SeedData(). This script is for
--       reference or manual SQL Server setup.
-- ============================================================

INSERT INTO Departments (Name) VALUES
    ('Engineering'),
    ('Human Resources');

INSERT INTO Employees (Name, Email, DepartmentId, BasicSalary, JoiningDate, IsActive) VALUES
    ('Ravi Sharma',   'ravi.sharma@company.com',   1, 30000.00, '2022-01-10', 1),
    ('Priya Mehta',   'priya.mehta@company.com',   1, 45000.00, '2021-06-15', 1),
    ('Amit Kulkarni', 'amit.kulkarni@company.com', 1, 52000.00, '2020-03-20', 1),
    ('Sunita Patil',  'sunita.patil@company.com',  2, 38000.00, '2022-08-01', 1),
    ('Deepak Joshi',  'deepak.joshi@company.com',  2, 41000.00, '2021-11-05', 1);

-- Attendance for current month (adjust month/year as needed)
-- Employee 5 (Deepak) has 0 days present to demonstrate edge-case handling
DECLARE @Month INT = MONTH(GETDATE());
DECLARE @Year  INT = YEAR(GETDATE());

INSERT INTO Attendance (EmployeeId, Month, Year, DaysPresent, TotalWorkingDays) VALUES
    (1, @Month, @Year, 24, 26),
    (2, @Month, @Year, 26, 26),
    (3, @Month, @Year, 22, 26),
    (4, @Month, @Year, 25, 26),
    (5, @Month, @Year,  0, 26);  -- edge case: absent entire month
