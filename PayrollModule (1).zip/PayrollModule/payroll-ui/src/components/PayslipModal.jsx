import { useState, useEffect, useRef } from 'react';
import { api, MONTHS, formatCurrency } from '../api';

export function PayslipModal({ runId, employeeId, onClose }) {
  const [slip, setSlip] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const printRef = useRef(null);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    api.getPayslip(runId, employeeId)
      .then(data => { setSlip(data); setLoading(false); })
      .catch(e => { setError(e.message); setLoading(false); });
    return () => { document.body.style.overflow = ''; };
  }, [runId, employeeId]);

  const handlePrint = () => {
    const content = printRef.current.innerHTML;
    const win = window.open('', '_blank');
    win.document.write(`<html><head><title>Payslip</title>
      <style>
        body{font-family:Arial,sans-serif;padding:32px;color:#111}
        .title{font-size:22px;font-weight:bold;color:#1e40af;text-align:center}
        .subtitle{text-align:center;color:#6b7280;margin-bottom:20px}
        .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px 24px;margin:16px 0;padding:16px;background:#f8fafc;border-radius:8px}
        .info-label{font-size:11px;color:#6b7280}
        .info-value{font-weight:600;font-size:13px}
        table{width:100%;border-collapse:collapse;margin-top:16px}
        th{background:#1e40af;color:white;padding:8px 12px;text-align:left}
        td{padding:8px 12px;border-bottom:1px solid #e5e7eb}
        .net-row{background:#eff6ff;font-weight:700;color:#1e40af}
        .footer{font-size:11px;color:#9ca3af;text-align:center;margin-top:20px;padding-top:12px;border-top:1px solid #e5e7eb}
      </style></head><body>${content}</body></html>`);
    win.document.close();
    win.print();
  };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000 }}>
      <div style={{ background:'white', borderRadius:12, maxWidth:520, width:'90%', maxHeight:'90vh', overflow:'auto', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}>
        <div style={{ padding:'20px 24px 0', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <h3 style={{ margin:0, fontSize:17, fontWeight:700 }}>Employee Payslip</h3>
          <button onClick={onClose} style={{ background:'none', border:'none', fontSize:20, cursor:'pointer', color:'#6b7280' }}>×</button>
        </div>

        {loading && <div style={{ padding:40, textAlign:'center', color:'#6b7280' }}>Loading payslip...</div>}
        {error && <div style={{ padding:40, textAlign:'center', color:'#dc2626' }}>{error}</div>}

        {slip && (
          <div ref={printRef} style={{ padding:24 }}>
            <div className="title" style={{ fontSize:20, fontWeight:700, color:'#1e40af', textAlign:'center' }}>
              HR Tech Solutions Pvt. Ltd.
            </div>
            <div className="subtitle" style={{ textAlign:'center', color:'#6b7280', marginBottom:20, fontSize:13 }}>
              Payslip — Run ID #{slip.payrollRunId}
            </div>

            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 24px', background:'#f8fafc', padding:16, borderRadius:8, marginBottom:20 }}>
              <InfoItem label="Employee Name" value={slip.employeeName} />
              <InfoItem label="Employee ID" value={`EMP-${String(slip.employeeId).padStart(3,'0')}`} />
              <InfoItem label="Department" value={slip.department} />
              <InfoItem label="Basic Salary" value={formatCurrency(slip.basicSalary)} />
              <InfoItem label="Total Working Days" value={slip.totalWorkingDays} />
              <InfoItem label="Days Present" value={slip.daysPresent} />
            </div>

            <table style={{ width:'100%', borderCollapse:'collapse' }}>
              <thead>
                <tr style={{ background:'#1e40af', color:'white' }}>
                  <th style={{ padding:'8px 12px', textAlign:'left' }}>Component</th>
                  <th style={{ padding:'8px 12px', textAlign:'right' }}>Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{ borderBottom:'1px solid #e5e7eb' }}>
                  <td style={{ padding:'8px 12px', color:'#059669' }}>+ Gross Pay</td>
                  <td style={{ padding:'8px 12px', textAlign:'right' }}>{formatCurrency(slip.grossPay)}</td>
                </tr>
                <tr style={{ borderBottom:'1px solid #e5e7eb' }}>
                  <td style={{ padding:'8px 12px', color:'#dc2626' }}>− PF Deduction (12% of Basic)</td>
                  <td style={{ padding:'8px 12px', textAlign:'right' }}>{formatCurrency(slip.pFDeduction)}</td>
                </tr>
                <tr style={{ borderBottom:'1px solid #e5e7eb' }}>
                  <td style={{ padding:'8px 12px', color:'#dc2626' }}>− Professional Tax (Flat)</td>
                  <td style={{ padding:'8px 12px', textAlign:'right' }}>{formatCurrency(slip.professionalTax)}</td>
                </tr>
              </tbody>
              <tfoot>
                <tr style={{ background:'#eff6ff', fontWeight:700 }}>
                  <td style={{ padding:'12px', color:'#1e40af', fontSize:15 }}>Net Pay</td>
                  <td style={{ padding:'12px', textAlign:'right', color:'#1e40af', fontSize:17 }}>{formatCurrency(slip.netPay)}</td>
                </tr>
              </tfoot>
            </table>

            <div style={{ fontSize:11, color:'#9ca3af', textAlign:'center', marginTop:16, paddingTop:12, borderTop:'1px solid #e5e7eb' }}>
              This is a computer-generated payslip and does not require a signature.
            </div>
          </div>
        )}

        <div style={{ padding:'12px 24px 20px', display:'flex', gap:8, justifyContent:'flex-end', borderTop:'1px solid #e5e7eb' }}>
          {slip && (
            <button onClick={handlePrint} style={{
              padding:'8px 20px', background:'#1e40af', color:'white',
              border:'none', borderRadius:6, cursor:'pointer', fontWeight:600, fontSize:13
            }}>Print Payslip</button>
          )}
          <button onClick={onClose} style={{
            padding:'8px 20px', background:'#f3f4f6', color:'#374151',
            border:'none', borderRadius:6, cursor:'pointer', fontWeight:600, fontSize:13
          }}>Close</button>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ label, value }) {
  return (
    <div>
      <div style={{ fontSize:11, color:'#6b7280', marginBottom:2 }}>{label}</div>
      <div style={{ fontWeight:600, fontSize:13 }}>{value}</div>
    </div>
  );
}
