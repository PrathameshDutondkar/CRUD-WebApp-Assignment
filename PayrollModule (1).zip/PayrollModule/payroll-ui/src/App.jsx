import { useState, useEffect } from 'react';
import { api, MONTHS, formatCurrency } from './api';
import { PayslipModal } from './components/PayslipModal';
import './App.css';

const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;
const years = Array.from({ length: 5 }, (_, i) => currentYear - 2 + i);

export default function App() {
  const [tab, setTab] = useState('run');
  const [employees, setEmployees] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [payrollResult, setPayrollResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [viewMonth, setViewMonth] = useState(currentMonth);
  const [viewYear, setViewYear] = useState(currentYear);
  const [viewResult, setViewResult] = useState(undefined);
  const [viewLoading, setViewLoading] = useState(false);
  const [slip, setSlip] = useState(null);

  useEffect(() => {
    api.getEmployees().then(setEmployees).catch(console.error);
  }, []);

  const handleRunPayroll = async () => {
    setLoading(true);
    setMessage(null);
    setPayrollResult(null);
    try {
      const result = await api.runPayroll(selectedMonth, selectedYear);
      setPayrollResult(result);
      setMessage({ type: 'success', text: `Payroll for ${MONTHS[selectedMonth - 1]} ${selectedYear} finalised successfully!` });
    } catch (e) {
      if (e.status === 409) {
        setMessage({ type: 'conflict', text: e.message });
        const existing = await api.getPayroll(selectedMonth, selectedYear);
        setPayrollResult(existing);
      } else {
        setMessage({ type: 'error', text: e.message || 'An error occurred' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleViewPayroll = async () => {
    setViewLoading(true);
    setViewResult(undefined);
    try {
      const result = await api.getPayroll(viewMonth, viewYear);
      setViewResult(result);
    } catch {
      setViewResult(null);
    } finally {
      setViewLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'Inter, system-ui, sans-serif' }}>
      <header style={{ background: 'linear-gradient(135deg, #1e40af 0%, #3b82f6 100%)', color: 'white', padding: '16px 32px', boxShadow: '0 2px 12px rgba(30,64,175,0.3)' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>HR Payroll Module</h1>
            <p style={{ margin: '2px 0 0', fontSize: 13, opacity: 0.85 }}>Monthly Payroll Management System</p>
          </div>
          <div style={{ fontSize: 13, opacity: 0.8 }}>
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>
      </header>

      <nav style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 4 }}>
          {[['run', 'Run Payroll'], ['view', 'View Results'], ['employees', 'Employees']].map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)} style={{
              padding: '14px 20px', border: 'none', cursor: 'pointer', fontWeight: 600,
              fontSize: 14, background: 'transparent',
              color: tab === key ? '#1e40af' : '#6b7280',
              borderBottom: tab === key ? '2px solid #1e40af' : '2px solid transparent',
            }}>{label}</button>
          ))}
        </div>
      </nav>

      <main style={{ maxWidth: 1100, margin: '32px auto', padding: '0 32px' }}>

        {tab === 'run' && (
          <Card title="Run Monthly Payroll">
            <p style={{ color: '#6b7280', marginTop: 0 }}>
              Select a month and year, then click <strong>Run Payroll</strong>.
              Once finalised, a payroll run cannot be modified.
            </p>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-end', marginBottom: 20 }}>
              <div>
                <label style={labelStyle}>Month</label>
                <select value={selectedMonth} onChange={e => setSelectedMonth(+e.target.value)} style={selectStyle}>
                  {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Year</label>
                <select value={selectedYear} onChange={e => setSelectedYear(+e.target.value)} style={selectStyle}>
                  {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
              <button onClick={handleRunPayroll} disabled={loading} style={{
                padding: '10px 28px',
                background: loading ? '#93c5fd' : '#1e40af',
                color: 'white', border: 'none', borderRadius: 8,
                fontSize: 14, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', minWidth: 140
              }}>
                {loading ? 'Processing...' : 'Run Payroll'}
              </button>
            </div>

            {message && (
              <div style={{
                padding: '12px 16px', borderRadius: 8, marginBottom: 16, fontSize: 14, fontWeight: 500,
                background: message.type === 'success' ? '#d1fae5' : message.type === 'conflict' ? '#fef3c7' : '#fee2e2',
                color: message.type === 'success' ? '#065f46' : message.type === 'conflict' ? '#92400e' : '#991b1b',
              }}>
                {message.text}
              </div>
            )}
            {payrollResult && <PayrollTable run={payrollResult} onViewSlip={setSlip} />}
          </Card>
        )}

        {tab === 'view' && (
          <Card title="View Payroll Results">
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-end', marginBottom: 20 }}>
              <div>
                <label style={labelStyle}>Month</label>
                <select value={viewMonth} onChange={e => setViewMonth(+e.target.value)} style={selectStyle}>
                  {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Year</label>
                <select value={viewYear} onChange={e => setViewYear(+e.target.value)} style={selectStyle}>
                  {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
              <button onClick={handleViewPayroll} disabled={viewLoading} style={{
                padding: '10px 24px', background: '#1e40af', color: 'white',
                border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: 'pointer'
              }}>
                {viewLoading ? 'Loading...' : 'Fetch'}
              </button>
            </div>
            {viewResult === null && !viewLoading && (
              <div style={{ textAlign: 'center', padding: 40, color: '#9ca3af' }}>
                No payroll run found for {MONTHS[viewMonth - 1]} {viewYear}.
              </div>
            )}
            {viewResult && <PayrollTable run={viewResult} onViewSlip={setSlip} />}
          </Card>
        )}

        {tab === 'employees' && (
          <Card title="Employee Directory">
            {employees.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 40, color: '#9ca3af' }}>Loading...</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={tableStyle}>
                  <thead>
                    <tr style={{ background: '#1e40af', color: 'white' }}>
                      {['ID', 'Name', 'Email', 'Department', 'Basic Salary', 'Joining Date'].map(h => (
                        <th key={h} style={thStyle}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {employees.map((emp, i) => (
                      <tr key={emp.id} style={{ background: i % 2 === 0 ? 'white' : '#f8fafc' }}>
                        <td style={tdStyle}>EMP-{String(emp.id).padStart(3,'0')}</td>
                        <td style={{ ...tdStyle, fontWeight: 600 }}>{emp.name}</td>
                        <td style={tdStyle}>{emp.email}</td>
                        <td style={tdStyle}>
                          <span style={{
                            padding: '3px 10px', borderRadius: 20, fontSize: 12, fontWeight: 600,
                            background: emp.department === 'Engineering' ? '#dbeafe' : '#fce7f3',
                            color: emp.department === 'Engineering' ? '#1e40af' : '#9d174d'
                          }}>{emp.department}</span>
                        </td>
                        <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 600 }}>{formatCurrency(emp.basicSalary)}</td>
                        <td style={tdStyle}>{new Date(emp.joiningDate).toLocaleDateString('en-IN')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}
      </main>

      {slip && <PayslipModal runId={slip.runId} employeeId={slip.employeeId} onClose={() => setSlip(null)} />}
    </div>
  );
}

function PayrollTable({ run, onViewSlip }) {
  const totals = run.details.reduce((acc, d) => ({
    gross: acc.gross + d.grossPay, pf: acc.pf + d.pFDeduction,
    pt: acc.pt + d.professionalTax, net: acc.net + d.netPay,
  }), { gross: 0, pf: 0, pt: 0, net: 0 });

  return (
    <div>
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <StatCard label="Total Gross" value={formatCurrency(totals.gross)} color="#059669" />
        <StatCard label="Total PF" value={formatCurrency(totals.pf)} color="#dc2626" />
        <StatCard label="Prof. Tax" value={formatCurrency(totals.pt)} color="#d97706" />
        <StatCard label="Net Payout" value={formatCurrency(totals.net)} color="#1e40af" bold />
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={tableStyle}>
          <thead>
            <tr style={{ background: '#1e40af', color: 'white' }}>
              {['Employee','Dept','Basic','Present','Working','Gross Pay','PF','Prof Tax','Net Pay',''].map(h => (
                <th key={h} style={thStyle}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {run.details.map((d, i) => (
              <tr key={d.id} style={{ background: i % 2 === 0 ? 'white' : '#f8fafc' }}>
                <td style={{ ...tdStyle, fontWeight: 600 }}>{d.employeeName}</td>
                <td style={tdStyle}>
                  <span style={{
                    padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                    background: d.department === 'Engineering' ? '#dbeafe' : '#fce7f3',
                    color: d.department === 'Engineering' ? '#1e40af' : '#9d174d'
                  }}>{d.department}</span>
                </td>
                <td style={{ ...tdStyle, textAlign: 'right' }}>{formatCurrency(d.basicSalary)}</td>
                <td style={{ ...tdStyle, textAlign: 'center', fontWeight: 700, color: d.daysPresent === 0 ? '#dc2626' : d.daysPresent === d.totalWorkingDays ? '#059669' : '#374151' }}>
                  {d.daysPresent}
                </td>
                <td style={{ ...tdStyle, textAlign: 'center' }}>{d.totalWorkingDays}</td>
                <td style={{ ...tdStyle, textAlign: 'right' }}>{formatCurrency(d.grossPay)}</td>
                <td style={{ ...tdStyle, textAlign: 'right', color: '#dc2626' }}>{formatCurrency(d.pFDeduction)}</td>
                <td style={{ ...tdStyle, textAlign: 'right', color: '#d97706' }}>{formatCurrency(d.professionalTax)}</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 700, color: '#1e40af' }}>{formatCurrency(d.netPay)}</td>
                <td style={tdStyle}>
                  <button onClick={() => onViewSlip({ runId: run.id, employeeId: d.employeeId })} style={{
                    padding: '4px 12px', background: '#eff6ff', color: '#1e40af',
                    border: '1px solid #bfdbfe', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 600
                  }}>Payslip</button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ background: '#eff6ff', fontWeight: 700 }}>
              <td colSpan={5} style={{ ...tdStyle, textAlign: 'right', color: '#1e40af' }}>Totals</td>
              <td style={{ ...tdStyle, textAlign: 'right', color: '#059669' }}>{formatCurrency(totals.gross)}</td>
              <td style={{ ...tdStyle, textAlign: 'right', color: '#dc2626' }}>{formatCurrency(totals.pf)}</td>
              <td style={{ ...tdStyle, textAlign: 'right', color: '#d97706' }}>{formatCurrency(totals.pt)}</td>
              <td style={{ ...tdStyle, textAlign: 'right', color: '#1e40af' }}>{formatCurrency(totals.net)}</td>
              <td style={tdStyle}></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

function StatCard({ label, value, color, bold }) {
  return (
    <div style={{ background: 'white', border: `1px solid ${color}30`, borderRadius: 10, padding: '12px 20px', minWidth: 150, borderLeft: `4px solid ${color}` }}>
      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: bold ? 800 : 600, color }}>{value}</div>
    </div>
  );
}

function Card({ title, children }) {
  return (
    <div style={{ background: 'white', borderRadius: 12, padding: 28, boxShadow: '0 1px 4px rgba(0,0,0,0.08)', marginBottom: 24 }}>
      <h2 style={{ margin: '0 0 20px', fontSize: 18, fontWeight: 700, color: '#111827' }}>{title}</h2>
      {children}
    </div>
  );
}

const labelStyle = { display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 };
const selectStyle = { padding: '9px 14px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, color: '#374151', background: 'white', cursor: 'pointer' };
const tableStyle = { width: '100%', borderCollapse: 'collapse', fontSize: 13 };
const thStyle = { padding: '10px 14px', textAlign: 'left', fontWeight: 600, whiteSpace: 'nowrap' };
const tdStyle = { padding: '10px 14px', borderBottom: '1px solid #e5e7eb' };
